OrionImporter
=============

A template to allow you to add an action on your page to directly import code into Orion

Once you add a button (or other method) to call importIntoOrion(), a zip of your application can easily be imported directly into Orion to start coding
immediately.

See the index.html for an example

You need to include the **handoff** directory and the code from **index.html** plus add your zip inside the **handoff/download** directory.