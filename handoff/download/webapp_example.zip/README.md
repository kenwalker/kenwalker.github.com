webapp_example
==============

This repository is an example of a simple Mozilla Web Application.  This application was used as an example of editing and testing an application live using [OrionHub](http://orionhub.org) as the editor and self hosting site.

If you already are logged into OrionHub you can use the following URI template to populate a clone of this repository ([webapp example clone to OrionHub](http://orionhub.org/git/git-repository.html#,cloneGitRepository=git://github.com/kenwalker/webapp_example.git))

You can see the [Planet Orion](http://planetorion.org) blogpost explaining how to use this repository as well.

[Mozilla WebApp Development Using Orion](http://planetorion.org/news/?p=250)